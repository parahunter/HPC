#ifndef __WRITEPNG_H
#define __WRITEPNG_H

#ifdef  __cplusplus
extern "C" {
#endif

void writepng(char *filename, int *array, int x, int y);
void writepng_(char *filename, int *array, int *x, int *y);

#ifdef  __cplusplus
}
#endif

#endif
