#ifndef __MANDEL_H
#define __MANDEL_H

void mandel(int width, int height, int *image, int max_iter);

#endif
